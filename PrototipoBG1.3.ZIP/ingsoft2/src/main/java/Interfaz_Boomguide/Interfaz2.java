/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Interfaz_Boomguide;

import java.awt.*;
import java.util.HashSet;
import javax.swing.*;

/**
 *
 * @author maxwe
 */
public class Interfaz2 extends javax.swing.JFrame {
    
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Interfaz2.class.getName());
    public static boolean NombreEnSaludo = false;
    public static String NombreUsuario = "";
    public static String contraUsuario = "";
    public static String RutUsuario = "";
    public static int EdadUsuario = 0;
    public static boolean verif = false;
    public static boolean verifContra = false;

    /**
     * Creates new form Interfaz
     */
    

    public Interfaz2() {
        
        
        Color backgroundColor = new Color(250, 248, 240); // very light cream
        Color textColor = new Color(30, 30, 30); // dark text for contrast
        Color accentColor = new Color(70, 130, 180); // steel blue accent
        initComponents();
        setContentPane(jPanel1);
        enviarBoton.addActionListener(e -> procesarInput());
        inputField.addActionListener(e -> procesarInput());
    }
    
    
    private void procesarInput() {
        String userInput = inputField.getText().trim();
        if (userInput.isEmpty()) {
            return;
        }
        agregarChat("Tú: " + userInput);
        inputField.setText("");

        String respuestaAsistente;
        if (verif == true) {
            if (userInput.equalsIgnoreCase("hola") || userInput.toLowerCase().contains("hola")) {
                respuestaAsistente = crearSaludo();
                
            } else if (userInput.equalsIgnoreCase("¿cómo estás?")) {
                respuestaAsistente = "¡Estoy aquí para ayudarte en lo que necesites!";
                
            } else if (userInput.equalsIgnoreCase("¿como estas?")) {
                respuestaAsistente = "¡Estoy aquí para ayudarte en lo que necesites!";
                
            } else if (userInput.equalsIgnoreCase("Buenos días")) { 
                respuestaAsistente = "¡Buenos días! dime,¿con que puedo ayudarte?";
                
            } else if (userInput.equalsIgnoreCase("como estas?")) {
                respuestaAsistente = "¡Estoy aquí para ayudarte en lo que necesites!";
                
            } else if (userInput.equalsIgnoreCase("Cuales son mis preferencias?")) {
                if (contraUsuario.isEmpty()) {
                    if (EdadUsuario == 0) {
                        respuestaAsistente = "Aún no ingresas tu contraseña!\n\nLas preferencias registradas son:\nNombre: " + NombreUsuario + "\nEdad: \nRut: " + RutUsuario;
                    }else {
                        respuestaAsistente = "Aún no ingresas tu contraseña!\nLas preferencias registradas son:\nNombre: " + NombreUsuario + "\nEdad: " + EdadUsuario + "\nRut: " + RutUsuario;
                }
                }else {
                    Color fondo = new Color(30, 30, 40);
                    Color textPrimarioColor = new Color(150, 180, 250);
                    Color textSecundarioColor = Color.WHITE;
                    Color colorBotones = new Color(139, 92, 246);
                    JDialog contrasena = new JDialog(this, "Preferencias", true);
                    contrasena.setSize(350, 280);
                    contrasena.setLocationRelativeTo(this);
                    contrasena.setLayout(new GridBagLayout());
                    contrasena.getContentPane().setBackground(fondo);

                    GridBagConstraints gbc = new GridBagConstraints();
                    gbc.insets = new Insets(10, 15, 10, 15);
                    gbc.fill = GridBagConstraints.HORIZONTAL;
                    gbc.anchor = GridBagConstraints.WEST;

                    JLabel contraLabel = new JLabel("Ingresa tu contraseña:");
                    contraLabel.setFont(new Font("Segoe UI", Font.PLAIN, 18));
                    contraLabel.setForeground(textPrimarioColor);
                    gbc.gridx = 0;
                    gbc.gridy = 0;
                    contrasena.add(contraLabel, gbc);

                    JTextField contraField = new JTextField();
                    contraField.setFont(new Font("Segoe UI", Font.PLAIN, 18));
                    contraField.setBackground(fondo.darker());
                    contraField.setForeground(textSecundarioColor);
                    gbc.gridx = 1;
                    gbc.gridy = 0;
                    contrasena.add(contraField, gbc);

                    JButton saveButton = new JButton("Ingresar");
                    saveButton.setFont(new Font("Segoe UI", Font.BOLD, 18));
                    saveButton.setBackground(new Color(70, 130, 180));
                    saveButton.setForeground(Color.WHITE);
                    saveButton.setFocusPainted(false);
                    saveButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                    gbc.gridy = 4;
                    gbc.anchor = GridBagConstraints.CENTER;
                    contrasena.add(saveButton, gbc);

                    saveButton.addActionListener(e -> {
                        if (contraField.getText().equals(contraUsuario)) {
                            verifContra = true;
                            contrasena.dispose();
                        } else {
                            verifContra = false;
                            contrasena.dispose();
                        }
                    });
                    
                    contrasena.setVisible(true);
                    if (verifContra==true && EdadUsuario == 0){
                        respuestaAsistente = "Verificando contraseña...";
                        agregarChat("Asistente: " + respuestaAsistente);
                        respuestaAsistente = "...";
                        agregarChat("Asistente: " + respuestaAsistente);
                        respuestaAsistente = "\nLas preferencias registradas son:\nNombre: " + NombreUsuario + "\nRut: " + RutUsuario;  
                        verifContra=false;
                    }else if (verifContra==true && EdadUsuario != 0){
                        respuestaAsistente = "Verificando contraseña...";
                        agregarChat("Asistente: " + respuestaAsistente);
                        respuestaAsistente = "...";
                        agregarChat("Asistente: " + respuestaAsistente);
                        respuestaAsistente = "\nLas preferencias registradas son:\nNombre: " + NombreUsuario + "\nEdad: " + EdadUsuario + "\nRut: " + RutUsuario;
                        verifContra=false;
                    }else{
                        respuestaAsistente = "Verificando contraseña...";
                        agregarChat("Asistente: " + respuestaAsistente);
                        respuestaAsistente = "...";
                        respuestaAsistente = "La contraseña es incorrecta!";                                              
                    }
               }
        }else {
            respuestaAsistente = "Lo siento, todavía estoy aprendiendo. Por favor, prueba otra pregunta.";
        }
    }else {
    respuestaAsistente = "Se necesita un registro antes de hacer una consulta";
    }
        
    agregarChat("Asistente: " + respuestaAsistente);
} 

    private void agregarChat(String message) {
        chatArea.append(message + "\n\n");
        chatArea.setCaretPosition(chatArea.getDocument().getLength());
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        chatArea = new javax.swing.JTextArea();
        saludoLabel = new javax.swing.JLabel();
        inputField = new javax.swing.JTextField();
        enviarBoton = new javax.swing.JToggleButton();
        r1 = new javax.swing.JToggleButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(42, 119, 199));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jPanel1.setBackground(new java.awt.Color(30, 30, 40));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(200, 200, 200));
        jLabel2.setText("Version: a1.3");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(150, 180, 250));
        jLabel3.setText("BoomGuide");

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        chatArea.setEditable(false);
        chatArea.setBackground(new java.awt.Color(50, 50, 65));
        chatArea.setColumns(20);
        chatArea.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        chatArea.setForeground(new java.awt.Color(200, 200, 200));
        chatArea.setRows(5);
        chatArea.setMaximumSize(new java.awt.Dimension(246, 36));
        jScrollPane1.setViewportView(chatArea);
        chatArea.setLineWrap(true);
        Color accentColor = new Color(70, 130, 180); // steel blue accent
        chatArea.setWrapStyleWord(true);
        chatArea.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(accentColor, 2, true),
            BorderFactory.createEmptyBorder(10,10,10,10)
        ));

        saludoLabel.setBackground(new java.awt.Color(255, 255, 255));
        saludoLabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        saludoLabel.setForeground(new java.awt.Color(255, 255, 255));
        saludoLabel.setText("Hola! Soy el asistente virtual de BoomGuide ¿Como te ayudo el día de hoy?");

        enviarBoton.setBackground(new java.awt.Color(139, 92, 246));
        enviarBoton.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        enviarBoton.setText("->");
        enviarBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enviarBotonActionPerformed(evt);
            }
        });

        r1.setBackground(new java.awt.Color(139, 92, 246));
        r1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        r1.setText("Preferencias");
        r1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                r1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(r1)
                        .addGap(36, 36, 36)
                        .addComponent(inputField, javax.swing.GroupLayout.PREFERRED_SIZE, 449, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(enviarBoton))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(138, 138, 138)
                        .addComponent(jLabel3))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 696, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(saludoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 684, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(42, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2))
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(saludoLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 311, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inputField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(r1)
                    .addComponent(enviarBoton, javax.swing.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void enviarBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enviarBotonActionPerformed
    String mensaje = inputField.getText();
    if (mensaje.isEmpty()) {
            return;
    }
    agregarChat("\nTú: " + inputField.getText());
    inputField.setText("");
    
    }//GEN-LAST:event_enviarBotonActionPerformed

    private void r1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_r1ActionPerformed
        Color fondo = new Color(30, 30, 40);
        Color textPrimarioColor = new Color(150, 180, 250);
        Color textSecundarioColor = Color.WHITE;
        Color colorBotones = new Color(139, 92, 246);
        JDialog prefe = new JDialog(this, "Preferencias", true);
        prefe.setSize(450, 380);
        prefe.setLocationRelativeTo(this);
        prefe.setLayout(new GridBagLayout());
        prefe.getContentPane().setBackground(fondo);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // Name label and field
        JLabel nombreLabel = new JLabel("Tu nombre:");
        nombreLabel.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        nombreLabel.setForeground(textPrimarioColor);
        gbc.gridx = 0;
        gbc.gridy = 0;
        prefe.add(nombreLabel, gbc);

        JTextField nombreField = new JTextField(NombreUsuario);
        nombreField.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        nombreField.setBackground(fondo.darker());
        nombreField.setForeground(textSecundarioColor);
        gbc.gridx = 1;
        gbc.gridy = 0;
        prefe.add(nombreField, gbc);

        // RUT label and field
        JLabel rutLabel = new JLabel("Tu RUT:");
        rutLabel.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        rutLabel.setForeground(textPrimarioColor);
        gbc.gridx = 0;
        gbc.gridy = 1;
        prefe.add(rutLabel, gbc);

        JTextField rutField = new JTextField(RutUsuario);
        rutField.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        rutField.setBackground(fondo.darker());
        rutField.setForeground(textSecundarioColor);
        gbc.gridx = 1;
        gbc.gridy = 1;
        prefe.add(rutField, gbc);

        // Age label and field
        JLabel edadLabel = new JLabel("Tu edad:");
        edadLabel.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        edadLabel.setForeground(textPrimarioColor);
        gbc.gridx = 0;
        gbc.gridy = 2;
        prefe.add(edadLabel, gbc);

        JTextField edadField = new JTextField(EdadUsuario > 0 ? String.valueOf(EdadUsuario) : "");
        edadField.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        edadField.setBackground(fondo.darker());
        edadField.setForeground(textSecundarioColor);
        gbc.gridx = 1;
        gbc.gridy = 2;
        prefe.add(edadField, gbc);

        JLabel contraLabel = new JLabel("Tu Contraseña:");
        contraLabel.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        contraLabel.setForeground(textPrimarioColor);
        gbc.gridx = 0;
        gbc.gridy = 3;
        prefe.add(contraLabel, gbc);

        JTextField contraField = new JTextField();
        contraField.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        contraField.setBackground(fondo.darker());
        contraField.setForeground(textSecundarioColor);
        gbc.gridx = 1;
        gbc.gridy = 3;
        prefe.add(contraField, gbc);
        // Use name checkbox
        JCheckBox usarNombreCheckbox = new JCheckBox("Que me llame por mi nombre");
        usarNombreCheckbox.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        usarNombreCheckbox.setSelected(NombreEnSaludo);
        usarNombreCheckbox.setBackground(fondo); // mismo fondo que el diálogo
        usarNombreCheckbox.setForeground(textSecundarioColor); // texto blanco
        usarNombreCheckbox.setFocusPainted(false); // opcional: quita borde al enfocar

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        prefe.add(usarNombreCheckbox, gbc);

        // Save button
        JButton saveButton = new JButton("Guardar");
        saveButton.setFont(new Font("Segoe UI", Font.BOLD, 18));
        saveButton.setBackground(new Color(70, 130, 180));
        saveButton.setForeground(Color.WHITE);
        saveButton.setFocusPainted(false);
        saveButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        gbc.gridy = 5;
        gbc.anchor = GridBagConstraints.CENTER;
        prefe.add(saveButton, gbc);

        saveButton.addActionListener(e -> {
            NombreUsuario = nombreField.getText().trim();
            RutUsuario = rutField.getText().trim();
            contraUsuario=contraField.getText().trim();
            try {
                EdadUsuario = Integer.parseInt(edadField.getText().trim());
            } catch (NumberFormatException ex) {
                EdadUsuario = 0; // reset if invalid
            }
            NombreEnSaludo = usarNombreCheckbox.isSelected();
            if (NombreUsuario.isEmpty() && RutUsuario.isEmpty() && EdadUsuario==0 && contraUsuario.isEmpty()){
                verif=false;
            }else{
                verif=true;
            }
            prefe.dispose();
            // Refresh greeting
            if (NombreUsuario.isEmpty()){
                return;
            } else if (usarNombreCheckbox.isSelected()){
               saludoLabel.setText(crearSaludo()); 
            }else{
                 return;
             }         
        });
        
        prefe.setResizable(false);
        prefe.setVisible(true);
    
    }//GEN-LAST:event_r1ActionPerformed
    public static String crearSaludo() {
        if (NombreEnSaludo && !NombreUsuario.isBlank()) {
            return "¡Hola " + NombreUsuario + "! ¿En qué puedo ayudarte hoy?";
        }
        return "¡Hola! ¿En qué puedo ayudarte hoy?";
    }
   
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Interfaz2().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea chatArea;
    private javax.swing.JToggleButton enviarBoton;
    private javax.swing.JTextField inputField;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JToggleButton r1;
    public static javax.swing.JLabel saludoLabel;
    // End of variables declaration//GEN-END:variables
}
