/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package boomguide.ingsoft;
import Interfaz_Boomguide.*;
import java.util.Scanner;

/**
 *
 * @author maxwe
 */
public class IngSoft {

    public static void main(String[] args) {
            Interfaz2 vista2 = new Interfaz2();
            vista2.setVisible(true);
    }
}