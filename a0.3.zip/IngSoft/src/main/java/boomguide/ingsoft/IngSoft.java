/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package boomguide.ingsoft;
import Interfaz_Boomguide.*;
/**
 *
 * @author maxwe
 */
public class IngSoft {

    public static void main(String[] args) {
        Interfaz vista = new Interfaz();
        vista.setVisible(true);    }
}
